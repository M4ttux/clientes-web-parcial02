<template>
    <h1 class="mb-4 text-3xl text-center"><slot /></h1>
</template>